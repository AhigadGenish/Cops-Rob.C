#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <math.h>
#define MAX_SIZE 30 
#define MIN_SIZE 5
#define play 1
#define exit 0 

//Name: Ahigad Genish          //
//Date : 26/12/2020

void printNames(int decision) // print name function //
{  // initailize variables//
	static char first_name[10];
	static char last_name[10];
	if (decision == play)
	{ // get name from user //
		scanf("%s %s", first_name, last_name);
		printf("Hello %.10s %.10s, welcome to our app!\n", first_name, last_name);	
	}
	if (decision == exit)
	{ // if user finish , say goodbye //
		printf("Bye, %.10s %.10s.", first_name, last_name);
	}
}
int Get_rows(void) // function for the size of rows //
{
	int i;
	scanf("%d", &i);
	if (i > MAX_SIZE)
	{
		i = MAX_SIZE;

	}
	if (i < MIN_SIZE)
	{
		i = MIN_SIZE;
	}

	return i;
}

int Get_columns(int rows) // function for the size of columns //
{
   int j;
    scanf("%d", &j);
    
  if ((j > MAX_SIZE) && (j != -1))
  {
	j = MAX_SIZE;

  }
  if ((j < MIN_SIZE) && (j != -1))
  {
	j = MIN_SIZE;
  }
  if (j == -1)
  {
	  j = rows;
  }
  
return j;

} 
// function who get arguments from the game function and calculate distance from all cops//
int distance(int cop_location[5][3], int rob_location[2], int Num_Cops)
{
	// initailize variables//
	int i, Min_dis = 0 , dis;

	for (i = 0; i < Num_Cops;i++)
	{
		cop_location[i][2] = pow(cop_location[i][0] - rob_location[0], 2) + pow(cop_location[i][1] - rob_location[1], 2);
	}
	dis = cop_location[0][2];
	for (i = 1; i < Num_Cops;i++)
	{
		if (dis > cop_location[i][2])
		{
			dis = cop_location[i][2];
			Min_dis = i;
		}
		else if (dis == cop_location[i][2])
		{
			if (cop_location[i][0] < cop_location[Min_dis][0])
			{
				dis = cop_location[i][2];
				Min_dis = i;
			}
			else if (cop_location[i][0] == cop_location[Min_dis][0])
			{
				if (cop_location[i][1] < cop_location[Min_dis][1])
				{
					dis = cop_location[i][2];
					Min_dis = i;
				}
			}

		}
	}


	return Min_dis;

	//return the most closer cop from the robber//
	
}
int Cv_sR(int rows , int columns )
{   // function of game 1 //
	// initailize variables//
	int rob_location[2] = { 0 };
	int cop_location[5][3];
	int i = 0, j = 0, c = 0, r = 0, x = 0, y = 0, f = 0, g = 0, Num_Cops=0, Robber_dis=0, turn_Counter = 0;
	char Game_Table[MAX_SIZE][MAX_SIZE];
    for (i = 0; i < rows; i++)
	{
		for (j = 0; j < columns; j++)
		{
			Game_Table[i][j] =  '-' ;
		}		
	}
	// check where to locate the robber //
	if (rows % 2 != 0 && columns % 2 != 0)
	{Game_Table[rows / 2][columns / 2] = 'R';
	
		
		rob_location[0] = ((rows - 1) / 2);
		rob_location[1] = ((columns - 1) / 2);
	}
	else
	{
		Game_Table[(rows - 1) / 2][(columns - 1) / 2] = 'R';
		rob_location[0] = (rows / 2);
		rob_location[1] = (columns / 2);
	}

	// get number of cops//
	printf("How many cops (1-5)?\n");
	scanf("%d", &Num_Cops);

		for(i=0;i<Num_Cops;i++)
		{
			printf("Let's choose a cell:\n");
			scanf("%d\n%d", &x, &y);
			while (Game_Table[x][y] != '-')
			{
				scanf("%d\n%d", &x, &y);

			}
			Game_Table[x][y] = 'C';
			cop_location[i][0] = x;
			cop_location[i][1] = y;

			
		}
		// locate the cops in array to know their location //
		

			if (Num_Cops == 1 && (((cop_location[0][0] + rob_location[0]) + (cop_location[0][1] + rob_location[1])) % 2 == 0))
			{ // check if this is a special sitution and finish the game//
				printf("Well, Let's play!\n");
				printf("Initial states:\n");
				for (i = 0; i < rows; i++)
				{
					for (j = 0; j < columns;j++)
					{
						printf("%c", Game_Table[i][j]);
					}
					printf("\n");
				}
				printf("The rob managed to escape!\n");
				return 0;
			}
			printf("Well, Let's play!\n");
			printf("Initial states:\n");
			for (i = 0; i < rows; i++)
			{ //print the board //
				for (j = 0; j < columns;j++)
				{
					printf("%c", Game_Table[i][j]);
				}
				printf("\n");
			} // start the game in loop //
			for ( turn_Counter = 0 ; turn_Counter < 15 ; turn_Counter++ )
			{
				printf("Cops:\n");
				for (j = 0; j < columns; j++)
				{
					for (i = 0; i < rows; i++)
					{   // check aviable option to move for cops and print to user //
						if (Game_Table[i][j] == 'C' && (i+1)<=rows && (Game_Table[i + 1][j] == '-' || Game_Table[i + 1][j] == 'R'))
							printf("[%d,%d] -> [%d,%d]\n", i, j, i + 1, j);
						
						if (Game_Table[i][j] == 'C' && (i-1)>=0  &&(Game_Table[i - 1][j] == '-' || Game_Table[i - 1][j] == 'R'))
							printf("[%d,%d] -> [%d,%d]\n", i, j, i - 1, j);
						
						if (Game_Table[i][j] == 'C' && (j+1) <=columns && (Game_Table[i][j + 1] == '-' || Game_Table[i][j + 1] == 'R'))
							printf("[%d,%d] -> [%d,%d]\n", i, j, i, j + 1);
						
						if (Game_Table[i][j] == 'C' && (j-1) >=0 &&(Game_Table[i][j - 1] == '-' || Game_Table[i][j - 1] == 'R'))
							printf("[%d,%d] -> [%d,%d]\n", i, j, i, j - 1);

					}

				}
				// get new location for cops //
				scanf("%d\n%d\n%d\n%d", &f, &g, &r, &c);
				if (r == rob_location[0] && c == rob_location[1])
				{  // check if user move to rob location and finish the game //
					Game_Table[f][g] = '-';
					Game_Table[r][c] = 'C';
					for (i = 0; i < rows; i++)
					{
						for (j = 0; j < columns;j++)
						{
							printf("%c", Game_Table[i][j]);
						}
						printf("\n");
					}
					printf("The cops won!\n");
					return 0;

				}// update cops location in the array //
				Game_Table[f][g] = '-';
				Game_Table[r][c] = 'C';
				for (i = 0;i < Num_Cops;i++)
				{
					if (cop_location[i][0] == f && cop_location[i][1] == g)
					{
						cop_location[i][0] = r;
						cop_location[i][1] = c;
					}
				} 
				//print borad//
				for (i = 0; i < rows; i++)
				{
					for (j = 0; j < columns;j++)
					{
						printf("%c", Game_Table[i][j]);
					}
					printf("\n");
				}

				// go to function that calculate the distance by the location of the cops and the robber//
				distance(cop_location, rob_location, Num_Cops);
				Game_Table[rob_location[0]][rob_location[1]] = '-';
				Robber_dis = distance(cop_location, rob_location, Num_Cops);
				//check where the robber need to escape //
				if ((cop_location[Robber_dis][0] > rob_location[0]) && (rob_location[0] - 1 >=0 )&& (Game_Table[rob_location[0] - 1][rob_location[1]] == '-'))
				{  //update robber location in array //
					rob_location[0]--;
				}
				else if ((cop_location[Robber_dis][0] < rob_location[0]) && (rob_location[0] + 1 <=rows ) &&( Game_Table[rob_location[0] + 1][rob_location[1]] == '-'))
				{
					rob_location[0]++;
				}
				else if (cop_location[Robber_dis][0] == rob_location[0])
				{
					if ((cop_location[Robber_dis][1] > rob_location[1])  &&( rob_location[1] - 1 >=0 )&& (Game_Table[rob_location[0]][rob_location[1] - 1] == '-'))
					{
						rob_location[1] --;

					}
					if ((cop_location[Robber_dis][1] < rob_location[1])  && (rob_location[1] + 1 <= columns )&& (Game_Table[rob_location[0]][rob_location[1] + 1] == '-'))
					{
						rob_location[1] ++;
					}
				}
				//update robber position//
				Game_Table[rob_location[0]][rob_location[1]] = 'R';
				printf("Rob:\n");
				for (i = 0; i < rows; i++)
				{
					for (j = 0; j < columns;j++)
					{
						printf("%c", Game_Table[i][j]);
					}
					printf("\n");
				}
			} 
			// if cops didnt catch the robber after 30 turns ,(15 each) , rob win //
			printf("The rob managed to escape!\n"); 
	        return 0;
}// end of game one //

int Wv_sB()
{   // game 2//
	// initailize variables//
	int x_W = 0, y_W = 0, z_W = 0, r_W = 0, i = 0, j = 0, x_B = 0, y_B = 0, z_B = 0, r_B = 0, counter_turn = 0, count_step = 0;
	
	int White_location[2][2] = { 0,0,0,2 };
	int Black_location[2][2] = { 2,0,2,2 };
	char Chess_Table[3][3];
	//update chess table //
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3;j++)
		{
			Chess_Table[i][j] = '-';
		}
	}
	Chess_Table[0][0] = 'W';
	Chess_Table[0][2] = 'W';
	Chess_Table[2][0] = 'B';
	Chess_Table[2][2] = 'B';
	//print the board//
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3;j++)
		{
			printf("%c", Chess_Table[i][j]);
		}
		printf("\n");
	}
	for (counter_turn = 0 ; counter_turn < 15;counter_turn++)
	{ // start game in loop //
		printf("W:\n"); // turn of whites//
		scanf("%d\n%d\n%d\n%d", &x_W, &y_W, &z_W, &r_W); // get location from user to move the whites //
		for (i = 0;i < 2;i++)
		{
			if (White_location[i][0] == x_W && White_location[i][1] == y_W)
			{
				White_location[i][0] = z_W;
				White_location[i][1] = r_W;
			}
		} // update the new location in array//
	
		// print board //
		Chess_Table[x_W][y_W] = '-';
		Chess_Table[z_W][r_W] = 'W';
		for (i = 0; i < 3; i++)
		{
			for (j = 0; j < 3;j++)
			{
				printf("%c", Chess_Table[i][j]);
			}
			printf("\n");
		}

		
			// check any option of knight B movement and if they blocked , the whites win//
			
				 if (Chess_Table[Black_location[0][0] - 2][Black_location[0][1] + 1] == '-')
			     {   if( Black_location[0][0] - 2 >= 0 && Black_location[0][0] - 2 <= 2)
					 if(Black_location[0][1] + 1 >=0 && Black_location[0][1] + 1 <= 2)
					 count_step++;	
				 }
				 if (Chess_Table[Black_location[0][0] - 1][Black_location[0][1] + 2] == '-')
				 {
					 if (Black_location[0][0] - 1 >= 0 && Black_location[0][0] - 1 <= 2)
					 {
						 if (Black_location[0][1] + 2 >= 0 && Black_location[0][1] + 2 <= 2)
							 count_step++;
					 }
				 }

				 if (Chess_Table[Black_location[0][0] + 1][Black_location[0][1] + 2] == '-')

				 {
					 if (Black_location[0][0] + 1 >= 0 && Black_location[0][0] + 1 <= 2)
						 if (Black_location[0][1] + 2 >= 0 && Black_location[0][1] + 2 <= 2)
							 count_step++;
				 }
				 if (Chess_Table[Black_location[0][0] + 2 ][Black_location[0][1] + 1] == '-')
				 {
					 if (Black_location[0][0] + 2 >= 0 && Black_location[0][0]  +2 <= 2)
						 if (Black_location[0][1] + 1 >= 0 && Black_location[0][1] + 1 <= 2)
					         count_step++;
				 }

				 if (Chess_Table[Black_location[0][0] + 2][Black_location[0][1] - 1] == '-')
				 {
					 if (Black_location[0][0] + 2 >= 0 && Black_location[0][0] + 2 <= 2)
						 if (Black_location[0][1] - 1 >= 0 && Black_location[0][1] - 1 <= 2)
					        count_step++;
				 }
				 if (Chess_Table[Black_location[0][0] + 1][Black_location[0][1] - 2] == '-')
				 {
					 if (Black_location[0][0] + 1 >= 0 && Black_location[0][0] +1 <= 2)
						 if (Black_location[0][1] -2 >= 0 && Black_location[0][1] -2 <= 2)
					 count_step++;
				 }

				 if (Chess_Table[Black_location[0][0] - 1][Black_location[0][1] - 2] == '-')

				 {
					 if (Black_location[0][0] - 1 >= 0 && Black_location[0][0] - 1 <= 2)
						 if (Black_location[0][1] -2  >= 0 && Black_location[0][1] -2 <= 2)
					 count_step++;
				 }
				 if (Chess_Table[Black_location[0][0] - 2][Black_location[0][1] - 1] == '-')
				 {
					 if (Black_location[0][0] - 2 >= 0 && Black_location[0][0] - 2 <= 2)
						 if (Black_location[0][1] - 1 >= 0 && Black_location[0][1] - 1 <= 2)
				 
					 count_step++;
				 }



				 if (Chess_Table[Black_location[1][0] - 2][Black_location[1][1] + 1] == '-')
				 {
					 if (Black_location[1][0] - 2 >= 0 && Black_location[1][0] - 2 <= 2)
						 if (Black_location[1][1] + 1 >= 0 && Black_location[1][1] + 1 <= 2)
					 count_step++;
				 }
				 if (Chess_Table[Black_location[1][0] - 1][Black_location[1][1] + 2] == '-')
				 {
					 if (Black_location[1][0] - 1 >= 0 && Black_location[1][0] - 1 <= 2)
						 if (Black_location[1][1] + 2 >= 0 && Black_location[1][1] + 2 <= 2)
					         count_step++;
				 }

				 if (Chess_Table[Black_location[1][0] + 1][Black_location[1][1] + 2] == '-')
				 {
					 if (Black_location[1][0] +1 >= 0 && Black_location[1][0] +1 <= 2)
						 if (Black_location[1][1] + 2>= 0 && Black_location[1][1] + 2 <= 2)
					        count_step++;
				 }
				 if (Chess_Table[Black_location[1][0] + 2][Black_location[1][1] + 1] == '-')
				 {
					 if (Black_location[1][0] + 2 >= 0 && Black_location[1][0] + 2 <= 2)
						 if (Black_location[1][1] + 1 >= 0 && Black_location[1][1] + 1 <= 2)
					        count_step++;
				 }

				 if (Chess_Table[Black_location[1][0] + 2][Black_location[1][1] - 1] == '-')
				 {
					 if (Black_location[1][0]  + 2 >= 0 && Black_location[1][0] + 2 <= 2)
						 if (Black_location[1][1] - 1 >= 0 && Black_location[1][1] - 1 <= 2)
					         count_step++;
				 }
				 if (Chess_Table[Black_location[1][0] + 1][Black_location[1][1] - 2] == '-')
				 {
					 if (Black_location[1][0] +1 >= 0 && Black_location[1][0] +1 <= 2)
						 if (Black_location[1][1] -2 >= 0 && Black_location[1][1] -2  <= 2)
					           count_step++;
				 }

				 if (Chess_Table[Black_location[1][0] - 1][Black_location[1][1] - 2] == '-')
				 {
					 if (Black_location[1][0] - 1 >= 0 && Black_location[1][0] - 1 <= 2)
						 if (Black_location[1][1] - 2 >= 0 && Black_location[1][1] -2 <= 2)
					 count_step++;
				 }
				 if (Chess_Table[Black_location[1][0] - 2][Black_location[1][1] - 1] == '-')
				 {
					 if (Black_location[1][0] - 2 >= 0 && Black_location[1][0] - 2 <= 2)
						 if (Black_location[1][1] - 1 >= 0 && Black_location[1][1] - 1 <= 2)
					 count_step++;
				 }

				 if (count_step == 0)
				 { 
					 printf("The whites won!\n");
					 return 0;
				 }
				 
				 count_step = 0;
		// turn of black //
		printf("B:\n");
		scanf("%d\n%d\n%d\n%d", &x_B, &y_B, &z_B, &r_B); // get new location from user//
		for (i = 0;i < 2;i++)
		{
			if (Black_location[i][0] == x_B && Black_location[i][1] == y_B)
			{
				Black_location[i][0] = z_B;
				Black_location[i][1] = r_B;
			}
		} //update B location in array //
			
			Chess_Table[x_B][y_B] = '-';
			Chess_Table[z_B][r_B] = 'B';
			for (i = 0; i < 3; i++)
			{   //print board //
				for (j = 0; j < 3;j++)
				{
					printf("%c", Chess_Table[i][j]);
				}
				printf("\n");
			} // check any option of knight W movement and if they blocked , the blacks win//
			if (Chess_Table[White_location[0][0] - 2][White_location[0][1] + 1] == '-')
			{
				if (White_location[0][0] - 2 >= 0 && White_location[0][0] - 2 <= 2)
					if (White_location[0][1] + 1 >= 0 && White_location[0][1] + 1 <= 2)
				      count_step++;
			}
			if (Chess_Table[White_location[0][0] - 1][White_location[0][1] + 2] == '-')
			{
				if (White_location[0][0] - 1 >= 0 && White_location[0][0] - 1 <= 2)
					if (White_location[0][1] + 2 >= 0 && White_location[0][1] + 2 <= 2)
				count_step++;
			}

			if (Chess_Table[White_location[0][0] + 1][White_location[0][1] + 2] == '-')
			{
				if (White_location[0][0] +1 >= 0 && White_location[0][0] +1 <= 2)
					if (White_location[0][1] + 2 >= 0 && White_location[0][1] + 2 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[0][0] + 2][White_location[0][1] + 1] == '-')
			{
				if (White_location[0][0] + 2 >= 0 && White_location[0][0] + 2 <= 2)
					if (White_location[0][1] + 1 >= 0 && White_location[0][1] + 1 <= 2)
				count_step++;
			}

			if (Chess_Table[White_location[0][0] + 2][White_location[0][1] - 1] == '-')
			{
				if (White_location[0][0] + 2 >= 0 && White_location[0][0] + 2 <= 2)
					if (White_location[0][1] - 1 >= 0 && White_location[0][1] - 1 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[0][0] + 1][White_location[0][1] - 2] == '-')
			{
				if (White_location[0][0] + 1 >= 0 && White_location[0][0] +1 <= 2)
					if (White_location[0][1] -2 >= 0 && White_location[0][1] -2 <= 2)
				count_step++;
				
			}

			if (Chess_Table[White_location[0][0] - 1][White_location[0][1] - 2] == '-')
			{
				if (White_location[0][0] - 1 >= 0 && White_location[0][0] - 1 <= 2)
					if (White_location[0][1] -2 >= 0 && White_location[0][1] -2 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[0][0] - 2][White_location[0][1] - 1] == '-')
			{   if (White_location[0][0] - 2 >= 0 && White_location[0][0] - 2 <= 2)
					if (White_location[0][1] - 1 >= 0 && White_location[0][1]  - 1 <= 2)
			
				count_step++;
			}



			if (Chess_Table[White_location[1][0] - 2][White_location[1][1] + 1] == '-')
			{
				if (White_location[1][0] - 2 >= 0 && White_location[1][0] - 2 <= 2)
					if (White_location[1][1] + 1 >= 0 && White_location[1][1] + 1 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[1][0] - 1][White_location[1][1] + 2] == '-')
			{
				if (White_location[1][0] - 1 >= 0 && White_location[1][0] - 1 <= 2)
					if (White_location[1][1] + 2 >= 0 && White_location[1][1] + 2 <= 2)
				count_step++;
			}

			if (Chess_Table[White_location[1][0] + 1][White_location[1][1] + 2] == '-')
			{
				if (White_location[1][0] +1 >= 0 && White_location[1][0] +1 <= 2)
					if (White_location[1][1] + 2 >= 0 && White_location[1][1] + 2 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[1][0] + 2][White_location[1][1] + 1] == '-')
			{
				if (White_location[1][0] + 2 >= 0 && White_location[1][0] + 2 <= 2)
					if (White_location[1][1] + 1 >= 0 && White_location[1][1] + 1 <= 2)
				count_step++;
			}

			if (Chess_Table[White_location[1][0] + 2][White_location[1][1] - 1] == '-')
			{
				if (White_location[1][0] + 2 >= 0 && White_location[1][0] + 2 <= 2)
					if (White_location[1][1] - 1 >= 0 && White_location[1][1] - 1 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[1][0] + 1][White_location[1][1] - 2] == '-')
			{
				if (White_location[1][0] +1 >= 0 && White_location[1][0] +1 <= 2)
					if (White_location[1][1] -2 >= 0 && White_location[1][1] -2 <= 2)
				count_step++;
			}

			if (Chess_Table[White_location[1][0] - 1][White_location[1][1] - 2] == '-')
			{
				if (White_location[1][0] - 1 >= 0 && White_location[1][0] - 1 <= 2)
					if (White_location[1][1] -2 >= 0 && White_location[1][1] -2 <= 2)
				count_step++;
			}
			if (Chess_Table[White_location[1][0] - 2][White_location[1][1] - 1] == '-')
			{
				if (White_location[1][0] - 2 >= 0 && White_location[1][0] - 2 <= 2)
					if (White_location[1][1] - 1 >= 0 && White_location[1][1] - 1 <= 2)
				count_step++;
			}

			if (count_step == 0)
			{
				printf("The blacks won!\n");
				return 0;
			}
			count_step = 0;
	}

	// if passed 30 turns , this is a draw //
		printf("Tie\n");
		return 0;
	
// end of game 2 //
}
void ourApp()
{ // main application - managed the user to choose wathever he wants //
	int columns, rows;
	char choice;
	printNames(play);
	printf("Let's choose the size:\n");
	rows = Get_rows();
	columns = Get_columns ( rows );
	printf("Do you want to play [y/n]?\n");
	scanf(" %c", &choice);
	while (choice == 'y')
	{
		Cv_sR(rows,columns);
		Wv_sB();
		printf("Do you want to play [y/n]?\n");
		scanf(" %c", &choice);
	}
	printNames(exit);	
}



int main()
{ // go to the application //

    ourApp();
	return 0;

}